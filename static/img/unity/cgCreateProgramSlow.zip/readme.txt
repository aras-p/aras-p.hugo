Cg compilation seems to be quite slow (we're using cgCreateProgram).
It takes about 8 seconds to compile a simple (diffuse) shader
with 80 permutations inside on Pentium4 3GHz.

Tested with Cg 1.5 September 2006, September 2007, Cg 2.0 beta October 2007.

Repro: launch run.cmd, it will print resulting time to the console.

Profiling produces hotspots as shown in profiling.png, majority of the time is spent in
cgIsInterfaceType. We're not calling that ourselves, and we're not using interfaces either.
The shader that is compiled is in input.shader (with our custom effects-like stuff around),
and it uses include files in 'includes' folder.
